﻿using System;
using System.Linq;
using Google.Apis.CloudSpeechAPI.v1beta1;
using Google.Apis.Auth.OAuth2;
using Google.Apis.Services;
using System.IO;
using System.Threading;
using System.Web.Mvc;
using Google.Apis.Auth.OAuth2.Mvc;
using Newtonsoft.Json;
using System.Web;
using System.Threading.Tasks;
using Google.Apis.Translate.v2;
using System.Collections.Generic;
using TranslationsResource = Google.Apis.Translate.v2.Data.TranslationsResource;
using edu.stanford.nlp.trees;
using edu.stanford.nlp.sentiment;
using edu.stanford.nlp.neural.rnn;
using java.util;
using edu.stanford.nlp.pipeline;
using edu.stanford.nlp.ling;
using edu.stanford.nlp.util;
using System.Globalization;
using NAudio.Wave;

namespace RadioTransitCore.Controllers
{
    public class MessageProcessor
    {
        //check text for inappropriate words
        public bool validateText(string text, string langCode)
        {
            CultureInfo cultureInfo = new CultureInfo(langCode);
            string uppercaseText = text.ToUpper(cultureInfo);
            bool result = true;
            string blacklistPath;
            List<string> blacklist;

            //load blacklist
            blacklistPath = Path.Combine(HttpContext.Current.Server.MapPath("~/App_Data"), langCode + "-blacklist.txt");
            blacklist = new List<string>(File.ReadAllLines(blacklistPath));

            foreach (string word in blacklist)
            {
                if(uppercaseText.IndexOf(word.ToUpper(cultureInfo)) != -1)
                {
                    result = false;
                    break;
                }
            }

            return result;
        }

        //sentiment analysis
        public string analyzeText(string text)
        {
            
            string jarRoot = Path.Combine(HttpContext.Current.Server.MapPath("~/App_Data"), "corenlp/");
            string modelsRoot = Path.Combine(jarRoot, "edu/stanford/nlp/models");
            Properties properties;
            string currentDirectory = Environment.CurrentDirectory;
            StanfordCoreNLP pipeline;
            Annotation document;
            List<int> scores = new List<int>();
            List<int> wordsLength = new List<int>();
            float[] weightedSumScores = { 0, 0, 0, 0, 0 };
            int informationGain = 0;
            int scoreDistance = 0;
            float textVersusBoosted = 0;
            int score;
            int totalWords = 0;
            string result = "";
            Tree tree;

            try
            {
                // Annotation pipeline configuration
                properties = new Properties();
                properties.setProperty("annotators", "tokenize, ssplit, pos, lemma, ner, parse, dcoref");
                properties.setProperty("ner.useSUTime", "0");

                // We should change current directory, so StanfordCoreNLP could find all the model files automatically

                Directory.SetCurrentDirectory(jarRoot);
                pipeline = new StanfordCoreNLP(properties);
                Directory.SetCurrentDirectory(currentDirectory);

                document = new Annotation(text);

                // run all Annotators on this text
                pipeline.annotate(document);

                // these are all the sentences in this document
                // a CoreMap is essentially a Map that uses class objects as keys and has values with custom types
                var sentences = document.get(new CoreAnnotations.SentencesAnnotation().getClass()) as ArrayList;

                //retrieve the scores and word lengths of each sentence
                foreach (CoreMap sentence in sentences)
                {
                    tree = (Tree)sentence.get(typeof(edu.stanford.nlp.sentiment.SentimentCoreAnnotations.SentimentAnnotatedTree));
                    score = RNNCoreAnnotations.getPredictedClass(tree);
                    scores.Add(score);
                    var tokens = sentence.get(new CoreAnnotations.TokensAnnotation().getClass()) as ArrayList;
                    wordsLength.Add(tokens.size());
                    totalWords += tokens.size();
                }

                //create a weighted sum of the scores
                for (int i = 0; i < scores.Count; i++)
                {
                    if (i > 0)
                    {
                        informationGain = 1;
                        scoreDistance = 1;
                    }
                    else
                    {
                        informationGain = Math.Abs(wordsLength[i] - wordsLength[i - 1]);
                        scoreDistance = Math.Abs(scores[i] - scores[i - 1]);
                    }
                    textVersusBoosted = wordsLength[i] / totalWords;
                    weightedSumScores[scores[i]] += (informationGain * scoreDistance * textVersusBoosted) / wordsLength[i];
                }

                //return the sentiment with the maximum sum ["Very Negative", "Negative", "Neutral", "Positive", "Very Positive"];
                result = Array.IndexOf(weightedSumScores, weightedSumScores.Max()).ToString();
            }
            catch (Exception e)
            {
                result = "[Error] " + e.StackTrace + " " + e.Message;
            }

            return result;
        }

        //prepare credentials for Google Cloud
        public GoogleCredential getGoogleCloudCredentials(string[] scopes)
        { 
            var keyFilePath = Path.Combine(HttpContext.Current.Server.MapPath("~/App_Data"), "RadioTransit-3ecddcd47916.json");
            var stream = new FileStream(keyFilePath, FileMode.Open, FileAccess.Read);

            GoogleCredential credential = GoogleCredential.FromStream(stream);

            if (scopes == null)
                return credential;
            else
                return credential.CreateScoped(scopes);
        }

        //Google Translate API access
        public string translateText(string text, string targetLangCode)
        {
            string translationResult = "";
            CredentialsFetcher credentials = JsonConvert.DeserializeObject<CredentialsFetcher>(File.ReadAllText(Path.Combine(HttpContext.Current.Server.MapPath("~/App_Data"), "essentials.txt")));

            try
            {
                TranslateService googleTranslateService = new TranslateService(new BaseClientService.Initializer()
                { 
                    ApiKey = credentials.GoogleAPIKey,
                    ApplicationName = "RadioTransit",
                });

                var response = googleTranslateService.Translations.List(text , targetLangCode).Execute();
                var translations = new List<string>();

                foreach (TranslationsResource translation in response.Translations)
                {
                    translations.Add(translation.TranslatedText);
                }

                if (translations.Count == 0)
                    throw new Exception("No translations were returned");
                else
                    translationResult = HttpUtility.HtmlDecode(translations[0]);
            }
            catch (Exception e)
            {
                translationResult = "[Error] " + e.StackTrace + " " + e.Message;
            }

            return translationResult;
        }

        //Google Speech Recognition API access
        public string recognizeText(string id, string langCode)
        {
            string recognitionResult = ""; string gates = "";
            GoogleCredential credential = getGoogleCloudCredentials(new string[] { CloudSpeechAPIService.Scope.CloudPlatform });

            try
            {
                CloudSpeechAPIService googleSpeechService = new CloudSpeechAPIService(new BaseClientService.Initializer()
                {
                    HttpClientInitializer = credential,
                    ApplicationName = "RadioTransit",
                });

                var request = new Google.Apis.CloudSpeechAPI.v1beta1.Data.SyncRecognizeRequest()
                {
                    Config = new Google.Apis.CloudSpeechAPI.v1beta1.Data.RecognitionConfig()
                    {
                        Encoding = "LINEAR16",
                        SampleRate = 16000,
                        LanguageCode = langCode
                    },
                    Audio = new Google.Apis.CloudSpeechAPI.v1beta1.Data.RecognitionAudio()
                    {
                        Content = Convert.ToBase64String(File.ReadAllBytes(Path.Combine(HttpContext.Current.Server.MapPath("~/App_Data/Media"), id + ".wav")))
                    }
                };
                var response = googleSpeechService.Speech.Syncrecognize(request).Execute();

                // fetch results and decide about their validity depending on the confidence 
                float? confidence = 0;
                string transcript = ""; 
                foreach (var result in response.Results)
                {
                    foreach (var alternative in result.Alternatives)
                    {
                        if (confidence < alternative.Confidence)
                        {
                            confidence = alternative.Confidence;
                            transcript = alternative.Transcript;
                        }
                    }
                }
                if (confidence < 0.5)
                {
                    throw new Exception("Low confidence.");
                }
                else
                {
                    recognitionResult = HttpUtility.HtmlDecode(transcript);
                }
            }
            catch (Exception e)
            {
                recognitionResult = "[Error] " + e.StackTrace + " " + e.Message;
            }

            return recognitionResult;
        }

        public string generateSubtitles(string messageId)
        {
            string result = "";

            using (WaveFileReader reader = new WaveFileReader(Path.Combine(HttpContext.Current.Server.MapPath("~/App_Data/Media"), messageId + ".wav")))
            {
                TimeSpan span = reader.TotalTime;
            }
            return result;
        }

    }
}