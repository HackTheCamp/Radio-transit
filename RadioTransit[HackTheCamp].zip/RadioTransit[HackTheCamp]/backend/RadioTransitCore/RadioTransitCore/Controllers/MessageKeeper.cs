﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.Azure;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Blob;
using System.Threading.Tasks;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using RadioTransitCore.Models;
using Newtonsoft.Json;

namespace RadioTransitCore.Controllers
{
    public class MessageKeeper
    {
        public string storeMessageVideo(string base64EncodedData, string id)
        {
            string uri = "";
            byte[] videoBytes;
            CloudStorageAccount storageAccount;
            CloudBlobClient blobClient;
            CloudBlobContainer container;
            CloudBlockBlob blob;

            try
            {
                // Parse the connection string and return a reference to the storage account.
                storageAccount = CloudStorageAccount.Parse(CloudConfigurationManager.GetSetting("StorageConnectionString"));

                // Create the blob client.
                blobClient = storageAccount.CreateCloudBlobClient();

                // Retrieve a reference to a container.
                container = blobClient.GetContainerReference("videos");

                //Byte array from Base64 encoded data
                videoBytes = Convert.FromBase64String(base64EncodedData);


                blob = container.GetBlockBlobReference(id + ".webm");
                blob.Properties.ContentType = "video/webm";
                blob.UploadFromByteArray(videoBytes, 0, videoBytes.Length);

                uri = blob.StorageUri.PrimaryUri.AbsoluteUri;
            }
            catch (Exception e)
            {
                uri = "[Error] " + e.StackTrace + " " + e.Message;
            }

            return uri;
        }

        public string storeMessageMetaData(string messageId, int locationId, int sentiment)
        {
            string result = "ok";
            string connectionString;
            ConnectionStringSettings settings; 

            try
            {
                // Look for the name in the connectionStrings section.
                settings = ConfigurationManager.ConnectionStrings["DatabaseConnectionString"];

                // If found, return the connection string.
                if (settings != null)
                    connectionString = settings.ConnectionString;
                else
                    throw new Exception("No connection string found.");

                //query database
                using (SqlConnection sqlConnection = new SqlConnection(connectionString))
                {
                    using (SqlCommand sqlCommand = new SqlCommand("INSERT INTO [dbo].[rt_messages]([id], [locationid], [timecollected], [sentiment]) VALUES(@Id, @Locationid, @Sentiment)", sqlConnection))
                    {
                        //add parameter values and execute
                        sqlCommand.CommandType = CommandType.Text;
                        sqlCommand.Parameters.Add("@Id", SqlDbType.Char).Value = messageId;
                        sqlCommand.Parameters.Add("@Locationid", SqlDbType.Int).Value = locationId;
                        sqlCommand.Parameters.Add("@Sentiment", SqlDbType.Int).Value = sentiment;
                        sqlConnection.Open();
                        sqlCommand.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception e)
            {
                result = "[Error] " + e.StackTrace + " " + e.Message;
            }

            return result;
        }

        public string storeMessageText(string messageId, string text, string langcode, int original)
        {
            string result = "ok";
            string connectionString;
            ConnectionStringSettings settings;

            try
            {
                // Look for the name in the connectionStrings section.
                settings = ConfigurationManager.ConnectionStrings["DatabaseConnectionString"];

                // If found, return the connection string.
                if (settings != null)
                    connectionString = settings.ConnectionString;
                else
                    throw new Exception("No connection string found.");

                //query database
                using (SqlConnection sqlConnection = new SqlConnection(connectionString))
                {
                    using (SqlCommand sqlCommand = new SqlCommand("INSERT INTO [dbo].[rt_texts]([messageid], [locationid], [document], [original]) VALUES(@Id, @Document, @LangCode, @Original)", sqlConnection))
                    {
                        //add parameter values and execute
                        sqlCommand.CommandType = CommandType.Text;
                        sqlCommand.Parameters.Add("@Id", SqlDbType.Char).Value = messageId;
                        sqlCommand.Parameters.Add("@Document", SqlDbType.NVarChar).Value = text;
                        sqlCommand.Parameters.Add("@LangCode", SqlDbType.Char).Value = langcode;
                        sqlCommand.Parameters.Add("@Original", SqlDbType.Int).Value = original;
                        sqlConnection.Open();
                        sqlCommand.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception e)
            {
                result = "[Error] " + e.StackTrace + " " + e.Message;
            }

            return result;
        }

        public string getLocations()
        {
            string connectionString;
            ConnectionStringSettings settings;
            SqlDataReader reader;
            List<Location> list = new List<Location>();
            string result = "";

            try
            {
                // Look for the name in the connectionStrings section.
                settings = ConfigurationManager.ConnectionStrings["DatabaseConnectionString"];

                // If found, return the connection string.
                if (settings != null)
                    connectionString = settings.ConnectionString;
                else
                    throw new Exception("No connection string found.");

                //query database
                using (SqlConnection sqlConnection = new SqlConnection(connectionString))
                {
                    using (SqlCommand sqlCommand = new SqlCommand("SELECT * FROM [dbo].[rt_locations] ORDER BY [label]", sqlConnection))
                    {
                        //execute command
                        sqlCommand.CommandType = CommandType.Text;
                        sqlConnection.Open();
                        reader = sqlCommand.ExecuteReader();

                        //read results
                        while (reader.Read())
                        {
                            list.Add(new Location { LocationId = reader["id"].ToString(), Label = reader["label"].ToString() });
                        }

                        result = JsonConvert.SerializeObject(list);
                    }
                }
            }
            catch (Exception e)
            {
                result = "[Error] " + e.StackTrace + " " + e.Message;
            }

            return result;
        }

        public string getMessages(int locationId)
        {
            string connectionString;
            ConnectionStringSettings settings;
            SqlDataReader reader;
            List<Message> list = new List<Message>();
            string result = "";

            try
            {
                // Look for the name in the connectionStrings section.
                settings = ConfigurationManager.ConnectionStrings["DatabaseConnectionString"];

                // If found, return the connection string.
                if (settings != null)
                    connectionString = settings.ConnectionString;
                else
                    throw new Exception("No connection string found.");

                //query database
                using (SqlConnection sqlConnection = new SqlConnection(connectionString))
                {
                    using (SqlCommand sqlCommand = new SqlCommand("SELECT [id], FORMAT([timeuploaded], 'yyyy-MM-dd') AS [timeuploaded], "+
                                                                  "[sentiment] FROM [dbo].[rt_messages] where locationid = @Locationid ORDER BY [timeuploaded]", sqlConnection))
                    {
                        //add parameter values and execute
                        sqlCommand.CommandType = CommandType.Text;
                        sqlCommand.Parameters.Add("@Locationid", SqlDbType.Int).Value = locationId;
                        sqlConnection.Open();
                        reader = sqlCommand.ExecuteReader();

                        //read results
                        while (reader.Read())
                        {
                            list.Add(new Message { Id = reader["id"].ToString(), Timeuploaded = reader["timeuploaded"].ToString(), Sentiment = reader["sentiment"].ToString()});
                        }

                        result = JsonConvert.SerializeObject(list);
                    }
                }
            }
            catch (Exception e)
            {
                result = "[Error] " + e.StackTrace + " " + e.Message;
            }

            return result;
        }

        public string getMessageText(string messageId, string langCode)
        {
            string connectionString;
            ConnectionStringSettings settings;
            SqlDataReader reader;
            List<string> list = new List<string>();
            string result = "";

            try
            {
                // Look for the name in the connectionStrings section.
                settings = ConfigurationManager.ConnectionStrings["DatabaseConnectionString"];

                // If found, return the connection string.
                if (settings != null)
                    connectionString = settings.ConnectionString;
                else
                    throw new Exception("No connection string found.");

                //query database
                using (SqlConnection sqlConnection = new SqlConnection(connectionString))
                {
                    using (SqlCommand sqlCommand = new SqlCommand("SELECT [document] FROM [dbo].[rt_texts] where [messageid] = @MessageId and languageCode = @LangCode", sqlConnection))
                    {
                        //add parameter values and execute
                        sqlCommand.CommandType = CommandType.Text;
                        sqlCommand.Parameters.Add("@MessageId", SqlDbType.Char).Value = messageId;
                        sqlCommand.Parameters.Add("@LangCode", SqlDbType.Char).Value = langCode;
                        sqlConnection.Open();
                        reader = sqlCommand.ExecuteReader();

                        //read results
                        while (reader.Read())
                        {
                            list.Add(reader["document"].ToString());
                        }

                        result = JsonConvert.SerializeObject(list);
                    }
                }
            }
            catch (Exception e)
            {
                result = "[Error] " + e.StackTrace + " " + e.Message;
            }

            return result;
        }


        public string getMessageTexts(string messageId)
        {
            string connectionString;
            ConnectionStringSettings settings;
            SqlDataReader reader;
            List<MessageText> list = new List<MessageText>();
            string result = "";

            try
            {
                // Look for the name in the connectionStrings section.
                settings = ConfigurationManager.ConnectionStrings["DatabaseConnectionString"];

                // If found, return the connection string.
                if (settings != null)
                    connectionString = settings.ConnectionString;
                else
                    throw new Exception("No connection string found.");

                //query database
                using (SqlConnection sqlConnection = new SqlConnection(connectionString))
                {
                    using (SqlCommand sqlCommand = new SqlCommand("SELECT [document], [languageCode] FROM [dbo].[rt_texts] where [messageid] = @MessageId", sqlConnection))
                    {
                        //add parameter values and execute
                        sqlCommand.CommandType = CommandType.Text;
                        sqlCommand.Parameters.Add("@MessageId", SqlDbType.Char).Value = messageId;
                        sqlConnection.Open();
                        reader = sqlCommand.ExecuteReader();

                        //read results
                        while (reader.Read())
                        {
                            list.Add(new MessageText { Text = reader["document"].ToString(), LangCode = reader["languageCode"].ToString()});
                        }

                        result = JsonConvert.SerializeObject(list);
                    }
                }
            }
            catch (Exception e)
            {
                result = "[Error] " + e.StackTrace + " " + e.Message;
            }

            return result;
        }

    }
}