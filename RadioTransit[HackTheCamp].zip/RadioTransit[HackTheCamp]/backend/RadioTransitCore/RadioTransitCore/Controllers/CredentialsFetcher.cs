﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace RadioTransitCore.Controllers
{
    public class CredentialsFetcher
    {
        public string MapboxToken { get; set; }
        public string GoogleAPIKey{get; set;}
    }
}