﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;
using RadioTransitCore.Models;
using System.Web.Http.Cors;

namespace RadioTransitCore.Controllers
{
    [EnableCors(origins: "*", headers: "*", methods: "*")]
    public class MessageController : ApiController
    {
        public string Get()
        {
            return "ok";
        }

        public string Get(int id)
        {
            if (id == 2)
                return getTranslation();
            else if (id == 3)
                return getLocations();
            else if (id == 4)
            {
                MessageProcessor processor = new MessageProcessor();
                return processor.analyzeText("This is a very beautiful moment. I am so happy.");
            }

            return "no id was identified";
        }


        [Route("translate")]
        [HttpGet]
        public string getTranslation()
        {
            MessageProcessor processor = new MessageProcessor();
            return processor.translateText("Please help", "fr");
        }

        [Route("validate")]
        [HttpGet]
        public string getValidation()
        {
            MessageProcessor processor = new MessageProcessor();
            bool result = processor.validateText("testing fucking ", "en");
            return result ? "valid" : "invalid";
        }

        [Route("locations")]
        [HttpPost]
        public string getLocations()
        {
            MessageKeeper keeper = new MessageKeeper();
            return keeper.getLocations();
        }

        [Route("messagetexts")]
        [HttpPost]
        public string getMessageTexts(SingleValue value)
        {
            MessageKeeper keeper = new MessageKeeper();
            return keeper.getMessageTexts(value.Data);
        }

        [Route("messages")]
        [HttpPost]
        public string getMessages(SingleValue value)
        {
            MessageKeeper keeper = new MessageKeeper();
            int locationId = 0;
            if (Int32.TryParse(value.Data, out locationId))
                return keeper.getMessages(Int32.Parse(value.Data));
            else
                return "[Error]";
        }

        [Route("newmessage")]
        [HttpPost]
        public string storeNewMessage(MessageData requestData)
        {
            string result ="";
            string requestID = Guid.NewGuid().ToString("N");
            requestData.Audio = normalizeBase64(requestData.Audio);
            requestData.Video = normalizeBase64(requestData.Video);
            MessageKeeper keeper = new MessageKeeper();
            result = keeper.storeMessageVideo(requestData.Video, requestID);
            if (result.IndexOf("[Error]") == -1)
                result += keeper.storeMessageMetaData(requestID, requestData.LocationId, 5);
            //result = getRecognition(requestData.Audio, requestID, requestData.LanguageCode);
            return result;
        }

        public string getRecognition(string data, string requestID, string langCode)
        {
            MessageProcessor processor = new MessageProcessor();
            
            string result = saveFromBase64(data, requestID, "wav");
            if(result.IndexOf("[Error]") != -1)
            {
                return result;
            }
            return processor.recognizeText(requestID, langCode);
        }

        //remove mime type, fix length
        private string normalizeBase64(string data)
        {
            string[] parts = HttpUtility.UrlDecode(data).Split(',');
            string result = "";
            int modulo = 0;

            if (parts.Length > 1)
            {
                result = parts[1];
                result = result.Replace(" ", "+");
                modulo = result.Length % 4;
                if (modulo > 0)
                {
                    result += new string('=', 4 - modulo);
                }
            }
            else
            {
                result = "";
            }

            return result;
        }

        private string saveFromBase64(string base64EncodedData, string id, string extension)
        {
            string result = "";

            try
            {
                var base64EncodedBytes = System.Convert.FromBase64String(base64EncodedData);
                File.WriteAllBytes(Path.Combine(HttpContext.Current.Server.MapPath("~/App_Data/Media"), id + "." + extension), base64EncodedBytes);
            }
            catch (Exception e)
            {
                result = "[Error] " + e.StackTrace + " " + e.Message;
            }

            return result;
        }
    }
}
