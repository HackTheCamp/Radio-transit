﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace RadioTransitCore.Models
{
    public class MessageData
    {
        public string Audio { get; set; }
        public string Video { get; set; }
        public int LocationId { get; set; }
        public string LanguageCode { get; set; }
    }
}