﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace RadioTransitCore.Models
{
    public class SingleValue
    {
        public string Data { get; set; }
    }
}