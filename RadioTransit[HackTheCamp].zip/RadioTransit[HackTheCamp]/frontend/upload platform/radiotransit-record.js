var audio_context;
var recorder;
var files = [];
var encodedData = [];

function setupVideoRecorder()
{
	setupAudioRecorder();
	
	var videoRecorder = videojs("videoRecorder",
	{
		controls: true,
		width: 400,
		height: 200,
		plugins: {
			record: {
				audio: true,
				video: {
					// video constraints: set resolution of camera
					mandatory: {
						//minWidth: 1280,
						//minHeight: 720,
						sourceId: document.getElementById("devices").value
					},
				},
				// dimensions of captured video frames
				frameWidth: 1280,
				frameHeight: 720,
				maxLength: 120,
				debug: true
			}
		}
	});
	
	document.getElementById("videoRecorder").muted = true;
	audios = document.querySelectorAll("audio");
	[].forEach.call(audios, function(audio) { audio.muted = true; });

	// error handling
	videoRecorder.on('deviceError', function()
	{
		console.log('device error:', videoRecorder.deviceErrorCode);
	});
	videoRecorder.on('error', function(error)
	{
		console.log('error:', error);
	});

	// user clicked the record button and started recording
	videoRecorder.on('startRecord', function()
	{
		//start audio recording in parallel
		recorder.clear();
		recorder && recorder.record();
		console.log('started recording!');
	});

	// user completed recording and stream is available
	videoRecorder.on('finishRecord', function()
	{
		recorder && recorder.stop();
		
		// the blob object contains the recorded data that
		// can be downloaded by the user, stored on server etc.
		console.log('finished recording: ', videoRecorder.recordedData);
		if($("#local").prop("checked"))
		{
			var d = new Date();
			var datestring = d.getDate()  + "-" + (d.getMonth()+1) + "-" + d.getFullYear() + "_" +
			d.getHours() + d.getMinutes();
			videoData = videoRecorder.recordedData.video || videoRecorder.recordedData;
			saveAs(videoData, "video_" + datestring + ".webm");
			
			recorder && recorder.exportWAV(function(blob) {
				var url = URL.createObjectURL(blob);
				saveAs(blob, "audio_" + datestring + ".wav");
			});
		}
	}); 
}

function setupAudioRecorder()
{
	window.AudioContext = window.AudioContext || window.webkitAudioContext;
	navigator.getUserMedia = navigator.getUserMedia || navigator.webkitGetUserMedia;
	window.URL = window.URL || window.webkitURL;
	try
	{
		audio_context = new AudioContext;
		if(navigator.getUserMedia)
		{
			navigator.getUserMedia({audio: true},
			function(stream)
			{
				var input = audio_context.createMediaStreamSource(stream);    
				input.connect(audio_context.destination);    
				recorder = new Recorder(input);
			},
			function(e) 
			{
				console.log('No live audio input: ' + e);
			});
			
		}
	}
	catch (e) 
	{
		console.log('No web audio support in this browser!');
    }
}

//upload the data of the message
function uploadMessage()
{
	jQuery.ajax({
		url: "",
		type: "POST",
		data: JSON.stringify({"Audio" : encodedData["audio"], "Video" : encodedData["video"], "LocationId" : $("#sourceLocation").val(),
			   "LanguageCode" : $("#langCodes").val()}),
		contentType: "application/json",
		async: true, 
	}).done(function(data) { 
		console.log(data);
	});
}

//read files to base64 strings
function prepareData()
{
	files = []
	encodedData = []
	files.push(document.getElementById('message-video').files[0]);
	files.push(document.getElementById('message-audio').files[0]);
	
	for(var i=0; i< files.length; i++)
	{
		var reader = new FileReader();
		reader.onload = (function(index,total){ 
			return function(event){
				var key = index == 0 ? "video" : "audio";
				encodedData[key] =  event.target.result;
				if(Object.keys(encodedData).length == 2)
				{
					uploadMessage();
				}
			};
		})(i,files.length);
		reader.readAsDataURL(files[i]);
	}
}

$(document).ready(function()
{ 
	$("body").fadeIn("slow");
	
	if (navigator.mediaDevices.enumerateDevices) 
	{
		//retrieve a list of the present devices
		navigator.mediaDevices.enumerateDevices().then(function(devices) 
		{
			devices.forEach(function(device) 
			{
				if(device.kind.indexOf("video") != -1)
				{
					var deviceSelect = document.getElementById("devices");
					var option = document.createElement("option");
					option.text = device.kind + ": " + device.label;
					option.value = device.deviceId; 
					deviceSelect.appendChild(option);
				}
			});
		}).catch(function(err) 
		{
			console.log(err.name + ": " + error.message);
		});

		//setup the recorder when a device is selected
		$("#deviceConfirm").click(function()
		{
			$(this).prop("disabled", true);
			setupVideoRecorder();  
		});
	}
	else
	{
		$("#recording").html("Video recording is not supported for this browser.");
	}
	
	//retrieve locations
	$.post("URL",
	{},
	function(data)
	{
		var locations = $.parseJSON(data);
		var html = "";
		for(var i=0; i<locations.length; i++)
		{
			html += '<option value="'+locations[i].LocationId+'">'+locations[i].Label+"</option>";
		}
		$("#sourceLocation").html(html);
	});
	
	// ui events
	$(".action").click(function()
	{
		var index = $(this).data("action");
		$(".action").removeClass("option-selected");
		$(this).addClass("option-selected");
		
		$(".section").hide();
		//make upload details available according to user's selection
		$(".section").eq(index).fadeIn(1000);
	});
	
	$('#local').change(function()
	{
		if(!$(this).prop("checked"))
		{
			$('#uploadDetails').fadeIn("slow");
		}
		else
		{
			$('#uploadDetails').fadeOut("slow");
		}
	});
	
	$("#uploadMessage").click(function()
	{
		prepareData();
	});
	
	$(".action").eq(0).click();
	
	synthesizeText("Welcome to the internal interface of Radio Transit for message collection. Please mute your device before recording.", "en-us");
});
