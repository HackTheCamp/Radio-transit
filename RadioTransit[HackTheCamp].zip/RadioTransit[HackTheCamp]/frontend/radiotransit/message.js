var messageTexts;
var locationIds = [];

//INNOETICS API call (http://www.innoetics.com)
function synthesizeText(message, language)
{
	voices = [];
	voices["en-us"] = "ian";
	voices["fr"] = "nadine";
	voices["el"] = "maria";
	voices["de"] = "claudia";
	voices["es"] = "pedro";
	voices["it"] = "riccardo";
	
	jQuery.post("//www.ttsvoice.com/api/speak.php",
	{
		"voice" : voices[language],
		"lang" : language,
		"outputformat" : "json",
		"text" : message,
		"user" : "USER",
		"key" : "KEY"
	},
	function(data)
	{
		var audio = document.getElementById('ttsplayer');
		audio.src = data.url;
		audio.load();
		audio.play();
	});
}

function getMessages(locationid)
{
	jQuery.post("",
	{
		"Data" : locationid
	},
	function(data)
	{
		var messages = jQuery.parseJSON(data);
		var html = "";
		for(var i=0; i<messages.length; i++)
		{
			messages[i].Id = messages[i].Id.trim();
			html += '<video class="previewvideo '+getSentimentClass(messages[i].Sentiment)+'" data-id="'+messages[i].Id+'" data-sentiment="'+messages[i].Sentiment+'"'; 
			html += 'src="https://URL'+messages[i].Id+'.webm" preload="meta"></video>';
		}
		jQuery("#videostrip").html(html);
		
		if(messages.length > 0)
		{
			loadMessageVideo(messages[0].Id, messages[0].Sentiment);

			jQuery(".previewvideo").click(function()
			{
				loadMessageVideo(jQuery(this).data("id"), jQuery(this).data("sentiment"));
			});
		}
		else
		{
			jQuery("#no-messages").show();
		}
	});	
}

function getSentimentClass(sentimentScore)
{
	var sentimentClass = "";
	if(sentimentScore > 3)
		sentimentClass = "positiveSentiment";
	else if(sentimentScore == 3)
		sentimentClass = "neutralSentiment";
	else
		sentimentClass = "negativeSentiment";
	return sentimentClass;
}

function loadMessageVideo(messageId, sentimentScore)
{
	var videoElement = document.getElementById("main-message");
	videoElement.src = "URL"+messageId+".webm";
	videoElement.load();
	var trackElement = document.getElementById("englishSubtitles");
	trackElement.src = "js/"+messageId+".js";
	jQuery('#main-message').attr('class', '');
	jQuery('#main-message').addClass(getSentimentClass(sentimentScore));
	getMessageTextData(messageId);
}


function getMessageTextData(messageid)
{
	jQuery.post("URL",
	{
		"Data" : messageid
	},
	function(data)
	{
		var response = jQuery.parseJSON(data);
		messageTexts = [];
		for(var i=0; i< response.length; i++)
	    {
			messageTexts[response[i].LangCode.trim()] = response[i].Text;
		}
	});
}

function getLocations()
{
	jQuery.post("URL",
	{},
	function(data)
	{
		var locations = jQuery.parseJSON(data);
		var html = "";
		for(var i=0; i<locations.length; i++)
		{
			locationIds[locations[i].Label] = locations[i].LocationId;
		}
	});
}

function messageSetup()
{
	jQuery(document).ready(function()
	{
		getLocations();
		var langCodes = ["en-us", "fr", "de", "el", "it", "es"];
		var html = "";
		for(var i=0; i<langCodes.length; i++)
		{
			html += '<img src="img/'+langCodes[i]+'.png" data-langCode="'+langCodes[i]+'" class="ttstrigger">';
		}
		jQuery("#flags").html(html);
		
		jQuery(document).on("click", ".ttstrigger", function()
		{
			var langCode = jQuery(this).data("langcode");
			if(typeof(messageTexts[langCode]) != "undefined")
				synthesizeText(messageTexts[langCode], langCode);
		});
		
		jQuery(document).on("click", ".leaflet-marker-icon", function()
		{
			getMessages(locationIds[jQuery(this).attr('title')]);
			if(jQuery("#text-9").css("display") == "none")
				jQuery("#text-9").fadeIn("slow");
			jQuery('html, body').animate({
				scrollTop: jQuery("#text-9 > .main-title").eq(0).offset().top - 60
			}, 1000);
		});
	});
}